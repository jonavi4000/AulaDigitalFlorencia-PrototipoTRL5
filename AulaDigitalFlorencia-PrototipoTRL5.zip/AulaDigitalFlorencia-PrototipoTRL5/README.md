
  # 💻 Aula Digital Florencia

  This is a code bundle for 💻 Aula Digital Florencia. The original project is available at https://www.figma.com/design/q5zxCrYZu1vbyONUYocw5c/%F0%9F%92%BB-Aula-Digital-Florencia.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  